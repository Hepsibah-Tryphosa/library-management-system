/**
 * JPA domain objects.
 */
package com.dp.lms.domain;
