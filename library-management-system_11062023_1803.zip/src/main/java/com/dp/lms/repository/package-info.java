/**
 * Spring Data JPA repositories.
 */
package com.dp.lms.repository;
