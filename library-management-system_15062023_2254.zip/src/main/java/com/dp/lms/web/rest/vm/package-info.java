/**
 * View Models used by Spring MVC REST controllers.
 */
package com.dp.lms.web.rest.vm;
