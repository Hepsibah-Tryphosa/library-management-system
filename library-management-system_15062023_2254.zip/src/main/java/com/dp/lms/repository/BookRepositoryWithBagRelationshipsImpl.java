package com.dp.lms.repository;

import com.dp.lms.domain.Book;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.hibernate.annotations.QueryHints;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

/**
 * Utility repository to load bag relationships based on https://vladmihalcea.com/hibernate-multiplebagfetchexception/
 */
public class BookRepositoryWithBagRelationshipsImpl implements BookRepositoryWithBagRelationships {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Optional<Book> fetchBagRelationships(Optional<Book> book) {
        return book.map(this::fetchCourses).map(this::fetchStudents).map(this::fetchBookHistories);
    }

    @Override
    public Page<Book> fetchBagRelationships(Page<Book> books) {
        return new PageImpl<>(fetchBagRelationships(books.getContent()), books.getPageable(), books.getTotalElements());
    }

    @Override
    public List<Book> fetchBagRelationships(List<Book> books) {
        return Optional
            .of(books)
            .map(this::fetchCourses)
            .map(this::fetchStudents)
            .map(this::fetchBookHistories)
            .orElse(Collections.emptyList());
    }

    Book fetchCourses(Book result) {
        return entityManager
            .createQuery("select book from Book book left join fetch book.courses where book is :book", Book.class)
            .setParameter("book", result)
            .setHint(QueryHints.PASS_DISTINCT_THROUGH, false)
            .getSingleResult();
    }

    List<Book> fetchCourses(List<Book> books) {
        HashMap<Object, Integer> order = new HashMap<>();
        IntStream.range(0, books.size()).forEach(index -> order.put(books.get(index).getId(), index));
        List<Book> result = entityManager
            .createQuery("select distinct book from Book book left join fetch book.courses where book in :books", Book.class)
            .setParameter("books", books)
            .setHint(QueryHints.PASS_DISTINCT_THROUGH, false)
            .getResultList();
        Collections.sort(result, (o1, o2) -> Integer.compare(order.get(o1.getId()), order.get(o2.getId())));
        return result;
    }

    Book fetchStudents(Book result) {
        return entityManager
            .createQuery("select book from Book book left join fetch book.students where book is :book", Book.class)
            .setParameter("book", result)
            .setHint(QueryHints.PASS_DISTINCT_THROUGH, false)
            .getSingleResult();
    }

    List<Book> fetchStudents(List<Book> books) {
        HashMap<Object, Integer> order = new HashMap<>();
        IntStream.range(0, books.size()).forEach(index -> order.put(books.get(index).getId(), index));
        List<Book> result = entityManager
            .createQuery("select distinct book from Book book left join fetch book.students where book in :books", Book.class)
            .setParameter("books", books)
            .setHint(QueryHints.PASS_DISTINCT_THROUGH, false)
            .getResultList();
        Collections.sort(result, (o1, o2) -> Integer.compare(order.get(o1.getId()), order.get(o2.getId())));
        return result;
    }

    Book fetchBookHistories(Book result) {
        return entityManager
            .createQuery("select book from Book book left join fetch book.bookHistories where book is :book", Book.class)
            .setParameter("book", result)
            .setHint(QueryHints.PASS_DISTINCT_THROUGH, false)
            .getSingleResult();
    }

    List<Book> fetchBookHistories(List<Book> books) {
        HashMap<Object, Integer> order = new HashMap<>();
        IntStream.range(0, books.size()).forEach(index -> order.put(books.get(index).getId(), index));
        List<Book> result = entityManager
            .createQuery("select distinct book from Book book left join fetch book.bookHistories where book in :books", Book.class)
            .setParameter("books", books)
            .setHint(QueryHints.PASS_DISTINCT_THROUGH, false)
            .getResultList();
        Collections.sort(result, (o1, o2) -> Integer.compare(order.get(o1.getId()), order.get(o2.getId())));
        return result;
    }
}
